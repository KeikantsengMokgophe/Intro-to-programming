// declare variables
var story = document.getElementById("story");
var siteFooter = document.getElementById("siteFooter");
var question = document.getElementById("question");
var answer = document.getElementById("answer");
var yourAnswer = document.getElementById("yourAnswer");
var submit = document.getElementById("submit");
// todo: make an empty array called answers
/* todo: listen for clicks on the submit button and call 
the getAnswer() function when they happen. */
// todo: call the function to ask the first question
/* askQuestion() asks a question, based on the number 
passed to it */
function askQuestion(questionNumber) {
}
/* getAnswer() gets the answer from the text field and 
pushes it into the answers array, then calls 
the continueStory function */
function getAnswer() {
}
/* continueStory() displays part of the story or an error 
based on the value of an item in the answers 
array */
function continueStory(answerNumber) {
}
/* theEnd() ends the story and hides the input field */
function theEnd() {
}
